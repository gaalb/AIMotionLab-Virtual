from aiml_virtual.trajectory import TestServer


server = TestServer()

server.run()