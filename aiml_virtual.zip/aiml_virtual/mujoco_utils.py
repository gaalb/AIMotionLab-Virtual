import mujoco

def get_freejoint_names(model: mujoco.MjModel) -> list[str]:
    """
    Get a list of the top-level freejoints in the mujoco model.

    Args:
        model (mujoco.MjModel): the model to inspect for freejoints

    Returns:
        list[str]: a list of the freejoint names as strings
    """

    n = model.njnt  # number of joints
    names = []
    for i in range(n):
        # I'm pretty sure this corresponds to mjsJoint, so here's the reference for it:
        # https://mujoco.readthedocs.io/en/latest/APIreference/APItypes.html#mjsjoint
        joint = model.joint(i)
        if joint.name != "" and joint.type[0] == mujoco.mjtJoint.mjJNT_FREE:
            names.append(joint.name)
    return names

