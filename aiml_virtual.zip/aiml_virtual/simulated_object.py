import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
import inspect
from typing import Optional, Type

import mujoco


class SimulatedObject(ABC):
    instance_count: dict[Type['SimulatedObject'], int] = {}
    xml_registry: dict[str, Type['SimulatedObject']] = {}

    # The __init_subclass__ function gets called when a subclass is defined. A subclass of SimulatedObject will be
    # (for example) MovingObject. MovingObject will include a call to super().__init_subclass__, which means that when
    # a concrete class (e.g. Drone) gets defined, MovingObject.__init_subclass__ gets called, which in turn will call
    # (via super().__init_subclass__) SimulatedObject.__init_subclass__, which is this function below.
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not inspect.isabstract(cls):  # skip for abstract classes: we don't want to (can't) instantiate them
            # Add the string name of the class to SimulatedObject's registry. We will use this registry to parse XML
            # files for objects to add to scene registries. This way, each class descended from SimulatedObject will
            # be a candidate to be parsed, without having to manually add them to a registry in Scene or elsewhere, and
            # without using globals(), which relies on having the correct imports in place: this approach is more
            # resistant to human error.
            # An alternative approach would be the following (not tested because it's not used, but OK in theory):
            # class Drone:
            #     SimulatedObject.xml_registry["drone"] = Drone  # this line runs only once; upon defining Drone
            # This is *way* simpler, however, when implementing new classes, the user must remember to add this line
            # to the new class, and therefore is more prone to human error.
            SimulatedObject.xml_registry[cls.__name__] = cls

            SimulatedObject.instance_count[cls] = 0

    def __init__(self):
        cls = self.__class__
        self.name = f"{cls.__name__}_{SimulatedObject.instance_count[cls]}"
        SimulatedObject.instance_count[cls] += 1
        self.model: Optional[mujoco.MjModel] = None
        self.data: Optional[mujoco.MjData] = None

    @abstractmethod
    def bind_to_model(self, model: mujoco.MjModel):
        pass

    @abstractmethod
    def bind_to_data(self, data: mujoco.MjData):
        pass

    # TODO: this probably won't be control step: rename i and control step to something more representative
    @abstractmethod
    def update(self, i: int, step: float) -> None:
        pass

    @abstractmethod
    def create_xml_element(self, pos: str, quat: str, color: str) -> dict[str, list[ET.Element]]:
        pass



