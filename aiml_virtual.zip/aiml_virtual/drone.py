import xml.etree.ElementTree as ET
import mujoco
from typing import Optional, Any
from enum import Enum
import numpy as np
from scipy.spatial.transform import Rotation

from aiml_virtual import controller
from aiml_virtual import moving_object
from aiml_virtual import controller
from aiml_virtual import trajectory

PROP_COLOR = "0.1 0.1 0.1 1.0"
PROP_LARGE_COLOR = "0.1 0.02 0.5 1.0"
SITE_NAME_END = "_cog"


class DummyDroneTrajectory(trajectory.Trajectory):
    def __init__(self):
        super().__init__()
        self.output["load_mass"] = 0.0
        self.output["target_pos"] = np.array([0, 0, 1])
        self.output["target_rpy"] = np.zeros(3)
        self.output["target_vel"] = np.zeros(3)
        self.output["target_acc"] = np.zeros(3)
        self.output["target_ang_vel"] = np.zeros(3)
        self.output["target_quat"] = np.zeros(4)
        self.output["target_quat_vel"] = np.zeros(4)

    def evaluate(self, state, i, step, time) -> dict:
        return self.output


class GeomControl(controller.Controller):
    def __init__(self, mass, inertia, gravity):
        super().__init__()
        self.k_r = 0.15
        self.k_v = 0.2
        self.k_R = 0.007
        self.k_w = 0.0015
        self.mass = mass
        self.inertia = inertia
        self.gravity = gravity

    def compute_control(self, *args, **kwargs):
        state = kwargs["state"]
        setpoint = kwargs["setpoint"]
        time = kwargs["time"]

        cur_pos = state['pos']
        cur_quat = state['quat']
        cur_vel = state['vel']
        cur_ang_vel = state['ang_vel']
        target_pos = setpoint['target_pos']
        target_vel = setpoint['target_vel']
        target_rpy = setpoint['target_rpy']
        target_rpy_rates = setpoint['target_ang_vel']
        mass = self.mass + setpoint['load_mass']
        pos_e = cur_pos - target_pos
        vel_e = cur_vel - target_vel
        target_acc = np.zeros(3)
        target_yaw = target_rpy[2]

        A = -self.k_r * pos_e - self.k_v * vel_e - \
            mass * self.gravity * np.array([0, 0, 1]) + self.mass * target_acc + self._mu_r(pos_e, vel_e)
        r3 = A / np.linalg.norm(A)
        if np.abs(target_yaw) < 1e-3:  # speed up cross product if yaw target is zero
            cross_temp = self._my_cross(r3)
            r2 = cross_temp / np.linalg.norm(cross_temp)
            r1 = self._my_cross_2(r2, r3)
        else:
            cross_temp = np.cross(r3, np.array([np.cos(target_yaw), np.sin(target_yaw), 0]))
            r2 = cross_temp / np.linalg.norm(cross_temp)
            r1 = np.cross(r2, r3)
        target_rotation = np.array([r1, r2, r3]).transpose()

        # Convert quaternion from scalar first to scalar last format
        cur_quat = np.roll(cur_quat, -1)
        cur_rotation = Rotation.from_quat(cur_quat).as_matrix()
        rot_e = 1 / 2 * self._veemap(np.dot((target_rotation.transpose()), cur_rotation)
                                     - np.dot(cur_rotation.transpose(), target_rotation))
        if np.isnan(np.sum(rot_e)):
            rot_e = np.zeros(3)
        ang_vel_e = cur_ang_vel - np.dot(np.dot(cur_rotation.transpose(), target_rotation), target_rpy_rates)
        target_torques = -self.k_R * rot_e - self.k_w * ang_vel_e + np.cross(cur_ang_vel,
                                                                             self.inertia * cur_ang_vel) - self.inertia @ self._mu_R(
            cur_quat, cur_ang_vel, rot_e, ang_vel_e)
        thrust = np.dot(A, np.dot(cur_rotation, np.array([0, 0, 1])))

        ctrl = np.zeros(4)
        ctrl[0] = thrust
        ctrl[1:4] = target_torques

        return ctrl

    def _mu_r(self, pos_e, vel_e):
        return np.zeros(3)

    def _mu_R(self, cur_quat, cur_ang_vel, rot_e, ang_vel_e):
        return np.zeros(3)

    @staticmethod
    def _veemap(mat):
        a = np.zeros(3)
        a[0] = mat[2, 1]
        a[1] = mat[0, 2]
        a[2] = mat[1, 0]
        return a

    @staticmethod
    def _hatmap(a):
        mat = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
        return mat

    @staticmethod
    def _quat_mult(quaternion1, quaternion0):
        """Multiply two quaternions in scalar last form"""
        x0, y0, z0, w0 = quaternion0
        x1, y1, z1, w1 = quaternion1
        return np.array([-x1 * x0 - y1 * y0 - z1 * z0 + w1 * w0,
                         x1 * w0 + y0 * z0 - z1 * y0 + w1 * x0,
                         -x1 * z0 + y1 * w0 + z1 * x0 + w1 * y0,
                         x1 * y0 - y1 * x0 + z1 * w0 + w1 * z0], dtype=np.float64)

    @staticmethod
    def _quat_conj(quat):
        """Return conjugate of a quaternion in scalar last form"""
        return np.array([-quat[0], -quat[1], -quat[2], quat[3]])

    def stability_analysis(self, k_r, k_v, k_R, k_w, c1, c2, J, m, eps=None):

        ######## Stability analysis of geometric ctrl based on the original paper #################

        Lmax = max(np.linalg.eigvals(J))
        Lmin = min(np.linalg.eigvals(J))
        psi1 = 0.01
        alpha = np.sqrt(psi1 * (2 - psi1))
        e_rmax = 0.001  # max{||e_v(0)||, B/(k_v*(1-alpha))}, TODO: see (23), (24)
        B = 0.0001  # B > ||-mge_3 + m\ddot{x}||  TODO: calculate B, see (16)
        W1 = np.array([[c1 * k_r / m * (1 - alpha), -c1 * k_v / (2 * m) * (1 + alpha)],
                       [-c1 * k_v / (2 * m) * (1 + alpha), k_v * (1 - alpha) - c1]])
        W12 = np.array([[c1 / m * B, 0], [B + k_r * e_rmax, 0]])
        W2 = np.array([[c2 * k_R / Lmax, -c2 * k_w / (2 * Lmin)], [-c2 * k_w / (2 * Lmin), k_w - c2]])
        exp1 = min([k_v * (1 - alpha),
                    4 * m * k_r * k_v * (1 - alpha) ** 2 / (k_v ** 2 * (1 + alpha) ** 2 + 4 * m * k_r * (1 - alpha)),
                    np.sqrt(k_r * m)])
        crit1 = c1 < exp1
        exp2 = min([k_w, 4 * k_w * k_R * Lmin ** 2 / (k_w ** 2 * Lmax + 4 * k_R * Lmin ** 2), np.sqrt(k_R * Lmin)])
        crit2 = c2 < exp2
        exp3 = [min(np.linalg.eigvals(W2)), 4 * np.linalg.norm(W12, ord=2) ** 2 / min(np.linalg.eigvals(W1))]
        crit3 = exp3[0] > exp3[1]

        return crit1, crit2, crit3

    @staticmethod
    def _my_cross(r3):
        '''
        Simplify cross product if the second vector is [0, 0, 1].
        '''
        return np.array([0, r3[2], -r3[1]])

    @staticmethod
    def _my_cross_2(a, b):
        '''
        Simplify cross product if the first vector is [0, a2, a3].
        '''
        return np.array([a[1] * b[2] - a[2] * b[1], a[2] * b[0], -a[1] * b[0]])


class CRAZYFLIE_PROP(Enum):
    #OFFSET = "0.047"
    OFFSET = "0.03275"
    OFFSET_Z = "0.0223"
    MOTOR_PARAM = "0.02514"
    MAX_THRUST = "0.16"
    MASS = "0.028"
    DIAGINERTIA = "1.4e-5 1.4e-5 2.17e-5"
    COG = "0.0 0.0 0.0"


class Drone(moving_object.MovingObject):
    def __init__(self):  # in addition to typing, also check if all of these variables are necessary
        super().__init__()
        self.controller: Optional[controller.Controller] = None  # TODO
        self.actr: Any = None  # TODO: type and explanation, for all under this too (got too lazy to write :) )
        self.ctrl: Any = None  # TODO: type
        self.sensor: Any = None  # TODO: type
        self.xquat: Any = None  # TODO: type
        self.qpos: Any = None  # TODO: type
        self.mass: Any = None  # TODO: type
        self.inertia: Any = None  # TODO: type
        self.prop_qpos: list[Any] = [None, None, None, None]
        self.prop_joint: list[Any] = [None, None, None, None]
        self.ctrl: list[Any] = [None, None, None, None]
        self.prop_angle: list[Any] = [None, None, None, None]
        self.actr_force: list[Any] = [None, None, None, None]
        self.qvel: Any = None
        self.qacc: Any = None
        self.sensor_gyro: Any = None
        self.sensor_velocimeter: Any = None
        self.sensor_accelerometer: Any = None
        self.sensor_posimeter: Any = None
        self.sensor_orimeter: Any = None
        self.sensor_ang_accelerometer: Any = None
        self.state: dict[str, Any] = {}
        self.ctrl_input = np.zeros(4)
        self.trajectory: Optional[trajectory.Trajectory] = None  # TODO: move this to moving_object

        self._create_input_matrix(float(CRAZYFLIE_PROP.OFFSET.value), float(CRAZYFLIE_PROP.OFFSET.value),
                                  float(CRAZYFLIE_PROP.OFFSET.value), float(CRAZYFLIE_PROP.MOTOR_PARAM.value))

    def _create_input_matrix(self, Lx1, Lx2, Ly, motor_param):
        self.input_mtx = np.array([[1/4, -1/(4*Ly), -1/(4*Lx2),  1 / (4*motor_param)],
                                  [1/4, -1/(4*Ly),   1/(4*Lx1), -1 / (4*motor_param)],
                                  [1/4,  1/(4*Ly),   1/(4*Lx1),  1 / (4*motor_param)],
                                  [1/4,  1/(4*Ly),  -1/(4*Lx2), -1 / (4*motor_param)]])

    def spin_propellers(self):
        for i in range(4):
            self.prop_angle[i] += self.ctrl[i][0]
            self.prop_qpos[i][0] = self.prop_angle[i]

    # todo: types
    def update(self, i: int, step: float) -> None:
        # if self.controller:
        #     self.ctrl[0] = self.controller.compute_control(i)
        # todo: check this as compared to the original when cleaning up
        try:
            self.spin_propellers()
            setpoint = self.trajectory.evaluate(self.state, i, step, self.data.time)
            ctrl = self.controller.compute_control(state=self.state, setpoint=setpoint, time=self.data.time)
            self.ctrl_input = ctrl
            motor_thrusts = self.input_mtx @ ctrl
            self.set_ctrl(motor_thrusts)
        except Exception as e:
            print(e.__repr__())

    def set_ctrl(self, ctrl):
        for i in range(4):
            self.ctrl[i][0] = ctrl[i]

    def bind_to_model(self, model: mujoco.MjModel):
        self.model = model
        self.mass = self.model.body(self.name).mass
        self.inertia = self.model.body(self.name).inertia


    def bind_to_data(self, data: mujoco.MjData):
        self.data = data
        free_joint = self.data.joint(self.name)
        self.xquat = self.data.body(self.name).xquat
        self.qpos = free_joint.qpos
        self.sensor_gyro = self.data.sensor(self.name + "_gyro").data
        self.sensor_velocimeter = self.data.sensor(self.name + "_velocimeter").data
        self.sensor_accelerometer = self.data.sensor(self.name + "_accelerometer").data
        self.sensor_posimeter = self.data.sensor(self.name + "_posimeter").data
        self.sensor_orimeter = self.data.sensor(self.name + "_orimeter").data
        self.sensor_ang_accelerometer = self.data.sensor(self.name + "_ang_accelerometer").data
        self.state: dict[str, Any] = {
            "pos": self.sensor_posimeter,
            "vel": self.sensor_velocimeter,
            "acc": self.sensor_accelerometer,
            "quat": self.sensor_orimeter,
            "ang_vel": self.sensor_gyro,
            "ang_acc": self.sensor_ang_accelerometer
        }
        for i in range(4):
            self.prop_joint[i] = self.data.joint(f"{self.name}_prop{i}")
            self.prop_qpos[i] = self.prop_joint[i].qpos
            self.prop_angle[i] = self.prop_qpos[i][0]  # ?????????????
            self.ctrl[i] = self.data.actuator(f"{self.name}_actr{i}").ctrl
            self.actr_force[i] = self.data.actuator(f"{self.name}_actr{i}").force
        self.controller = GeomControl(self.mass, self.inertia, self.model.opt.gravity)
        self.trajectory = DummyDroneTrajectory()

    def create_xml_element(self, pos: str, quat: str, color: str) -> dict[str, list[ET.Element]]:
        # TODO: separate crazyflie and bumblebee elements and common parts (for simplicity, just doing crazyflie for now)
        # NOTE: In the original version, the mass of the drone and the mass of the prop are getting confused and
        # weirdly overwritten. The add_drone_common_parts function wants a 'mass' parameter, and uses this mass
        # parameter to set the inertial element of the XML, which makes sense. HOWEVER, the actual value passed to
        # this mass parameter is CRAZYFLIE_PROP.MASS.value, which doesn't make sense. It is then overwritten to be
        # "0.00001", which is what is used to set the mass of the propellers, instead of CRAZYFLIE_PROP.MASS.value
        name = self.name
        mass = CRAZYFLIE_PROP.MASS.value
        diaginertia = CRAZYFLIE_PROP.DIAGINERTIA.value
        Lx1 = CRAZYFLIE_PROP.OFFSET.value
        Lx2 = CRAZYFLIE_PROP.OFFSET.value
        Ly = CRAZYFLIE_PROP.OFFSET.value
        Lz = CRAZYFLIE_PROP.OFFSET_Z.value
        motor_param = CRAZYFLIE_PROP.MOTOR_PARAM.value
        max_thrust = CRAZYFLIE_PROP.MAX_THRUST.value
        cog = CRAZYFLIE_PROP.COG.value
        rgba = color.split()
        color = rgba[0] + " " + rgba[1] + " " + rgba[2] + " 0.0"
        ss_color = rgba[0] + " " + rgba[1] + " " + rgba[2] + " 0.2"
        drone = ET.Element("body", name=name, pos=pos, quat=quat)  # this is the parent element

        ET.SubElement(drone, "geom", name=name + "_body", type="mesh", mesh="crazyflie_body", rgba=color)
        ET.SubElement(drone, "geom", name=name + "_4_motormounts", type="mesh", mesh="crazyflie_4_motormounts",
                      rgba=color)
        ET.SubElement(drone, "geom", name=name + "_4_motors", type="mesh", mesh="crazyflie_4_motors", rgba=color)

        ret = {"worldbody": [drone],
               "actuator": [],
               "sensor": []}
        ET.SubElement(drone, "geom", type="sphere", name=name + "_sphere", size="1.0", rgba=color, contype="0",
                      conaffinity="0")
        # TODO: safety sphere?
        # we give the inertia by hand instead of it auto-computing based on geoms
        ET.SubElement(drone, "inertial", pos=cog, diaginertia=diaginertia, mass=mass)
        ET.SubElement(drone, "joint", name=name, type="free")  # the free joint that allows this to move freely
        site_name = name + SITE_NAME_END
        ET.SubElement(drone, "site", name=site_name, pos="0 0 0", size="0.005")  # center of gravity
        prop_site_size = "0.0001"
        prop_mass = "0.00001"
        prop_pos = [f"{Lx2} -{Ly} {Lz}",
                    f"-{Lx1} -{Ly} {Lz}",
                    f"-{Lx1} {Ly} {Lz}",
                    f"{Lx2} {Ly} {Lz}"]
        for i in range(4):
            if i % 2 == 0:
                mesh = "crazyflie_ccw_prop"
            else:
                mesh = "crazyflie_cw_prop"
            prop_name = f"{name}_prop{i}"
            prop_body = ET.SubElement(drone, "body", name=prop_name)
            ET.SubElement(prop_body, "joint", name=prop_name, axis="0 0 1", pos=prop_pos[i])
            ET.SubElement(prop_body, "geom", name=prop_name, type="mesh", mesh=mesh, mass=prop_mass, pos=pos,
                          rgba=PROP_COLOR)
            ET.SubElement(drone, "site", name=prop_name, pos=pos, size=prop_site_size)
            actuator = ET.Element("general", site=prop_name, name=f"{name}_actr{i}", gear=f" 0 0 1 0 0 {motor_param}",
                                  ctrllimited="true", ctrlrange=f"0 {max_thrust}")
            ret["actuator"].append(actuator)
        ret["sensor"].append(ET.Element("gyro", site=site_name, name=name + "_gyro"))
        ret["sensor"].append(ET.Element("framelinvel", objtype="site", objname=site_name, name=name + "_velocimeter"))
        ret["sensor"].append(ET.Element("accelerometer", site=site_name, name=name + "_accelerometer"))
        ret["sensor"].append(ET.Element("framepos", objtype="site", objname=site_name, name=name + "_posimeter"))
        ret["sensor"].append(ET.Element("framequat", objtype="site", objname=site_name, name=name + "_orimeter"))
        ret["sensor"].append(ET.Element("frameangacc", objtype="site", objname=site_name, name=name + "_ang_accelerometer"))
        return ret


